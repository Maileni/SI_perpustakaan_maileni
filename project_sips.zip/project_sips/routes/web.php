<?php

use App\Http\Controllers\AnggotaController;
use App\Http\Controllers\BookController;
use App\Http\Controllers\PenggunaController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
 */

Route::get('/', function () {
    return view('welcome');
});
Route::get('/buku', [BookController::class, 'index'])->middleware('checkRole:admin');
Route::get('/tambahbuku', [BookController::class, 'tambahbuku'])->name('tambahbuku')->middleware('checkRole:admin');

Route::post('/insertdata', [BookController::class, 'insertdata'])->name('insertdata')->middleware('checkRole:admin');

Route::get('/tampilkandata/{id}', [BookController::class, 'tampilkandata'])->name('tampilkandata')->middleware('checkRole:admin');

Route::post('/updatedata/{id}', [BookController::class, 'updatedata'])->name('updatedata')->middleware('checkRole:admin');

Route::get('/delete/{id}', [BookController::class, 'delete'])->name('delete')->middleware('checkRole:admin');
Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
Route::get('/daftarbuku', 'DaftarController@index')->name('daftarbuku')->middleware('checkRole:user');
Route::get('/detail/{id}', 'DaftarController@detail')->name('detail')->middleware('checkRole:user');
Route::get('/profile', 'ProfileController@index')->name('profile');

Route::get('/cetakdata', 'PinjamController@cetakdata')->name('cetakdata')->middleware('checkRole:admin');
Route::get('/cetakpengembalian', 'PengembalianController@cetakpengembalian')->name('cetakpengembalian')->middleware('checkRole:admin');

Route::get('/anggota', [AnggotaController::class, 'DaftarAnggota'])->middleware('auth')->name('user');
Route::get('/pengguna', [PenggunaController::class, 'index'])->middleware('checkRole:admin');
Route::get('/tambahpengguna', [PenggunaController::class, 'tambahpengguna'])->name('tambahpengguna')->middleware('checkRole:admin');
Route::post('/store', [PenggunaController::class, 'store'])->name('store')->middleware('checkRole:admin');
Route::delete('/pengguna/{id}', [PenggunaController::class, 'destroy'])->middleware('checkRole:admin');
Route::get('/edit/{id}', [PenggunaController::class, 'edit'])->name('edit')->middleware('checkRole:admin');
Route::post('/update/{id}', [PenggunaController::class, 'update'])->name('update')->middleware('checkRole:admin');
//peminjaman kedua
Route::get('/pinjam', 'PinjamController@index');
Route::get('/pinjam/{id}', 'PinjamController@store');
Route::get('/pinjam/setujui/{id}', 'PinjamController@setujui')->middleware('checkRole:admin');
Route::get('/pinjam/tolak/{id}', 'PinjamController@tolak')->middleware('checkRole:admin');
//pengembalian
Route::get('/pengembalian', 'PengembalianController@index')->middleware('checkRole:admin');
Route::get('/pengembalian/{id}', 'PengembalianController@pengembalian')->middleware('checkRole:admin');
Route::get('/buku/status/{id}', 'BookController@status')->middleware('checkRole:admin');
