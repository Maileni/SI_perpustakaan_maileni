<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Profile extends Model
{
   protected $table = 'user';
   protected $fillable = [
      'image','name', 'email', 'password','address','phone'
  ];
}
