<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Pinjam extends Model
{
    protected $table = 'pinjam';

    public function book_r()
    {
        return $this->belongsTo('App\Models\Book', 'book');
    }
    public function user_r()
    {
        return $this->belongsTo('App\User', 'user');
    }
}
