<?php

namespace App\Http\Controllers;

use App\Pinjam;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;

class PinjamController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function index()
    {
        $title = 'halaman peminjaman buku';
        $data = Pinjam::paginate(10);

        return view('pinjam', compact('title', 'data'));
    }

    public function store($id)
    {
        $cek = \DB::table('books')->where('id', $id)->where('stok', '>', 0)->where('status', 1)->count();

        if ($cek > 0) {
            \DB::table('pinjam')->insert([
                'book' => $id,
                'user' => \Auth::user()->id,
                'created_at' => date('Y-m-d H:i:s'),
            ]);
            $book = \DB::table('books')->where('id', $id)->first();
            $qty_now = $book->stok;
            $qty_new = $qty_now - 1;

            \DB::table('books')->where('id', $id)->update([
                'stok' => $qty_new,
            ]);

            Session::flash('message', 'buku berhasil dipinjam');
            Session::flash('alert-class', 'alert-success');
            return redirect('daftarbuku');
        } else {
            Session::flash('message', 'Tidak Bisa Meminjam, Buku Ini Tidak Tersedia');
            Session::flash('alert-class', 'alert-danger');
            return redirect('daftarbuku');
        }}
    public function cetakdata()
    {
        $title = 'halaman peminjaman buku';
        $cetakdata = Pinjam::get();

        return view('cetakdata', compact('title', 'cetakdata'));
    }

    public function setujui($id)
    {
        Pinjam::where('id', $id)->update(['status' => 1]);

        return redirect('pinjam');
    }

    public function tolak($id)
    {
        Pinjam::where('id', $id)->update(['status' => 2]);

        return redirect('pinjam');
    }
}
