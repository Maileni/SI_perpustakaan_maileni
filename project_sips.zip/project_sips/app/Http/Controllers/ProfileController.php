<?php

namespace App\Http\Controllers;

use App\Http\Controllers\ProfileController;
use App\User;
use Auth;

class ProfileController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $user = User::where('id', Auth::user()->id)->first();
        return view('profile', compact('user'));

    }

    // public function update(Request $request)
    // {
    //     dd('$request');
    // $this->validate($request, [
    //     'password' => 'confirmed',
    // ]);
    // $user = User::where('id', Auth::user()->id)->first();
    // $user->name = $request->name;
    // $user->email = $request->email;
    // if (!empty($request->password)) {
    //     $user->password = Hash::make($request->password);
    // }
    // $user->address = $request->address;
    // $user->phone = $request->phone;
    // $user->update();
    // Alert::success('berhasil edit', 'Success');
    // return redirect('profile');

    // }
}
