<?php

namespace App\Http\Controllers;

use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class AnggotaController extends Controller
{
    public function DaftarAnggota(Request $request)
    {
        if ($request->has('search')) {
            $users = User::where('name', 'LIKE', '%' . $request->search . '%')->paginate(10);
            Session::put('halaman_url', request()->fullUrl());
        } else {
            $users = User::latest()->paginate(10);
            Session::put('halaman_url', request()->fullUrl());
        }
        return view('anggota', compact('users'));
    }
}
