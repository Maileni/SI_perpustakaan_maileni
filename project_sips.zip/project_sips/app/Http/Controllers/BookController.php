<?php

namespace App\Http\Controllers;

use App\Models\Book;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

// use DB;

class BookController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index(Request $request)
    {
        if ($request->has('search')) {
            $data = Book::where('judul', 'LIKE', '%' . $request->search . '%')->paginate(10);
            Session::put('halaman_url', request()->fullUrl());
        } else {
            $data = Book::latest()->paginate(10);
            Session::put('halaman_url', request()->fullUrl());
        }
        return view('buku', compact('data'));
    }
    public function tambahbuku()
    {
        return view('tambahdata');
    }

    public function insertdata(Request $request)
    {
        $this->validate($request, [

            'judul' => 'required',
            'penulis' => 'required',
            'penerbit' => 'required',
            'stok' => 'required',
            'sampul' => 'required|mimes:jpg,png,jpeg',

        ]);
        $data = Book::create($request->all());
        if ($request->hasfile('sampul')) {
            $request->file('sampul')->move('sampulbuku/', $request->file('sampul')->getClientOriginalName());
            $data->sampul = $request->file('sampul')->getClientOriginalName();
            $data->save();
        }
        return redirect('/buku')->with('success', 'Data Berhasil Ditambahkan');
    }

    public function tampilkandata($id)
    {
        $data = Book::find($id);
        return view('tampildata', compact('data'));
    }

    public function updatedata(Request $request, $id)
    {
        $data = Book::find($id);
        $this->validate($request, [

            'judul' => 'required',
            'penulis' => 'required',
            'penerbit' => 'required',
            'stok' => 'required',
            'sampul' => 'mimes:jpg,png,jpeg',
        ]);

        $data->update($request->all());
        if ($request->hasfile('sampul')) {
            $request->file('sampul')->move('sampulbuku/', $request->file('sampul')->getClientOriginalName());
            $data->sampul = $request->file('sampul')->getClientOriginalName();
            $data->save();
        }
        if (session('halaman_url')) {
            return Redirect(session('halaman_url'))->with('success', 'Data Berhasil Diubah');
        }
        return redirect('buku')->with('success', 'Data Berhasil Diubah');
    }

    public function delete($id)
    {
        $data = Book::find($id);
        $data->delete();
        return redirect('/buku')->with('success', 'Data Berhasil Dihapus');
    }
    public function status($id)
    {
        $data = \DB::table('books')->where('id', $id)->first();
        $status_baru = $data->status;
        if ($status_baru == 1) {
            \DB::table('books')->where('id', $id)->update([
                'status' => 0,
            ]);
        } else {
            \DB::table('books')->where('id', $id)->update([
                'status' => 1,
            ]);
        }
        Session::flash('message', 'status berhasil dirubah');
        Session::flash('alert-class', 'alert-success');
        return redirect('/buku');
    }
}
