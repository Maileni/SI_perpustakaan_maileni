<?php

namespace App\Http\Controllers;

use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;

class PenggunaController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index(Request $request)
    {
        if ($request->has('search')) {
            $pengguna = User::where('name', 'LIKE', '%' . $request->search . '%')->paginate(10);
            Session::put('halaman_url', request()->fullUrl());
        } else {
            $pengguna = User::latest()->paginate(10);
            Session::put('halaman_url', request()->fullUrl());
        }
        return view('pengguna', compact('pengguna'));
    }

    public function tambahpengguna()
    {
        return view('tambahpengguna');
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required',
            'email' => 'required|unique:users',
            'password' => 'required',
            'jenis_kelamin' => 'required',
            'kelas' => 'required',
            'jurusan' => 'required',
            'address' => 'required',
            'phone' => 'required',
        ]);

        $user = new User();
        $user->name = $request->name;
        $user->email = $request->email;
        $user->password = Hash::make($request->password);
        $user->jenis_kelamin = $request->jenis_kelamin;
        $user->kelas = $request->kelas;
        $user->jurusan = $request->jurusan;
        $user->address = $request->address;
        $user->phone = $request->phone;
        $user->save();

        Session::flash('message', 'Anggota Berhasil Ditambahkan');
        Session::flash('alert-class', 'alert-success');
        return redirect('pengguna');
    }

    public function destroy($id)
    {
        User::destroy($id);
        Session::flash('message', 'Anggota Berhasil Dihapus');
        Session::flash('alert-class', 'alert-success');
        return redirect('pengguna');
    }

    public function edit($id)
    {
        $user = User::find($id);
        return view('users/edit', compact('user'));
    }

    public function update(Request $request, $id)
    {
        $user = User::findorfail($id);
        $request->validate([
            'name' => 'required',
            'email' => 'required',
            'password' => 'required',
            'jenis_kelamin' => 'required',
            'kelas' => 'required',
            'jurusan' => 'required',
            'address' => 'required',
            'phone' => 'required',
        ]);
        $request['password'] = bcrypt($request['password']);
        $user->update($request->all());
        Session::flash('message', 'Anggota Berhasil Diubah');
        Session::flash('alert-class', 'alert-success');
        return redirect('pengguna');
    }
}
