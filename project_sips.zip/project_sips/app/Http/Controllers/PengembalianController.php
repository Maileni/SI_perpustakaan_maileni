<?php

namespace App\Http\Controllers;

use App\Models\Book;
use App\Pinjam;

class PengembalianController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function index()
    {
        $title = 'halaman pengembalian buku';
        $data = Pinjam::whereIn('status', [1, 3])->paginate(10);

        return view('pengembalian', compact('title', 'data'));
    }

    public function cetakpengembalian()
    {
        $title = 'halaman pengembalian buku';
        $datacetak = Pinjam::whereIn('status', [1, 3])->get();

        return view('cetakpengembalian', compact('title', 'datacetak'));
    }

    public function pengembalian($id)
    {
        $dt = Pinjam::find($id);
        $id_book = $dt->book;

        $book = Book::find($id_book);

        $now = $book->stok;
        $stok_pengembalian = $now + 1;

        Pinjam::where('id', $id)->update([
            'status' => 3,
        ]);

        Book::where('id', $id_book)->update([
            'stok' => $stok_pengembalian,
        ]);

        return redirect('pengembalian');
    }
}
