<?php

namespace App\Http\Controllers;

use App\Models\Book;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class DaftarController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function index(Request $request)
    {
        if ($request->has('search')) {
            $buku = Book::where('jenis_buku', 'LIKE', '%' . $request->search . '%')->paginate(10);
            Session::put('halaman_url', request()->fullUrl());
        } else {
            $buku = Book::latest()->paginate(10);
            Session::put('halaman_url', request()->fullUrl());
        }
        return view('daftarbuku', compact('buku'));
    }

    public function detail($id)
    {
        $buku = Book::where('id', $id)->first();

        return view('detail', compact('buku'));
    }
}
