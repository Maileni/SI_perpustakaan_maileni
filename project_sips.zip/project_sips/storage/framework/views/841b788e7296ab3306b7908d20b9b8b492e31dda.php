<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SI Perpustakaan</title>
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/landing.css')); ?>">
</head>

<body>
    <section class="hero-container">
        <div>
            <div>
                <h1>Fill Your Day By Reading
                </h1>
                <p>_.Result of Maileni._
                </p>
            </div>
        </div>
        <img src="sampulbuku/mai3.png" alt="hero">
    </section>

</body>

</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\application\project_sips\resources\views/welcome.blade.php ENDPATH**/ ?>