

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">grafik buku</div>

                <div class="card-body">
                <div id="grafik"></div>
    <script src="https://code.highcharts.com/highcharts.js"></script>
    <script type="text/javascript">
        var jumlah = <?php echo json_encode($total_buku) ?>;
        var bulan = <?php echo json_encode($bulan) ?>;
        Highcharts.chart('grafik', {
            title : {
                text: 'Grafik Jumlah Buku '
            },
            xAxis : {
                categories : bulan
            },
            yAxis : {
                title: 'Nominal Jumlah Bulanan'
            }
            },
            plotOption: {
                series: {
                    allowPointSelect: true
                }
            },
            series: [
                {
                    name: 'Nominal Jumlah',
                    data: jumlah
                }
            ]
            });
        </script>
         </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\application\project_sips\resources\views/buku-grafik.blade.php ENDPATH**/ ?>