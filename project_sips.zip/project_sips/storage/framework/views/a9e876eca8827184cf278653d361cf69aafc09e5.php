
<?php $__env->startSection('content'); ?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <style>
            html, body {
                background-image:url('<?php echo e(asset('sampulbuku/mai3.png')); ?>');
                background-size:cover;
                background-repeat: no-repeat;
                font-family: cambria;
                font-weight: 200;
            }
</style>
            }
</style>
    <title>SI Perpustakaan</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/img.css')); ?>">
  </head>
  <body>
    <h1 class="text-center mb-4"style="font-family:Times;color:#5F9EA0"> Edit Data buku</h1>
<div class="content">
    <div class="container">
        <div class="row justify-content-center" >
            <div class="col-8">
    
  </body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\application\project_sips\resources\views/editprofile.blade.php ENDPATH**/ ?>