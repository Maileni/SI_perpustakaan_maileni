

<?php $__env->startSection('content'); ?>
<!doctype html>
<html lang="en">

<head>
    <title>SI Perpustakaan</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,shrink-to-fit=no">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.css" integrity="sha512-3pIirOrwegjM6erE5gPSwkUzO+3cTjpnV9lexlNZqvupR64iZBnOOTiiLPb9M36zpMScbmUNIcHUqKD47M719g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        @media  only screen and (max-width:800px) {
            #no-more-tables tbody,
            #no-more-tables tr,
            #no-more-tables td {
                display: block;
            }
            #no-more-tables thead tr {
                position: absolute;
                top: -9999px;
                left: -9999px;
            }
            #no-more-tables td {
                position: relative;
                padding-left: 50%;
                border: none;
                border-bottom: 1px solid #5e8f81;
            }
            #no-more-tables td:before {
                content: attr(data-title);
                position: absolute;
                left: 6px;
                font-weight: bold;
            }
            #no-more-tables tr {
                border-bottom: 1px solid #ccc;
            }
        }
    </style>
</head>
<div class="head-title">
				<div class="left">
					<h1>Daftar Buku</h1>
					<ul class="breadcrumb">
						<li>
							<a href="/buku">Daftar Buku</a>
						</li>
						<li><i class='bx bx-chevron-right' ></i></li>
							<a class="active" href="/home">Beranda</a>
						</li>
					</ul>
          </div>
      </div>
          <?php if(session('message')): ?>
        <div class="alert <?php echo e(session('alert-class')); ?>">
            <?php echo e(session('message')); ?>

</div>
<?php endif; ?>
    <a href="/tambahbuku" class="btn btn-success mb-4"style="font-family:Times;"><i class="bi bi-cloud-plus"></i> Tambah</a>
    <form action="/buku" method="GET">
        <div class="input-group" style="width:200px;">
  <input type="search" class="form-control" name="search"placeholder="cari..">
</div>
        </form>
        </div>
<body>
        <div class="table-responsive mt-2" id="no-more-tables">
            <table class="table"style="background-color:#92b8ad; font-family:cambria;color:white;">
                <thead style=background-color:#5e8f81;font-family:cambria;color:white>
                <tr>
      <th scope="col">No</th>
      <th scope="col">Sampul</th>
      <th scope="col">Judul</th>
      <th scope="col">Penulis</th>
      <th scope="col">Penerbit</th>
      <th scope="col">Kategori</th>
      <th scope="col">Stok</th>
      <th scope="col">Status</th>
      <th scope="col">Tindakan</th>
      <th scope="col">Dibuat</th>
      <th scope="col">aksi</th>

    </tr>
                </thead>
                <tbody>
                <?php
      $no = 1;
    ?>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
    <td><?php echo e($index + $data->firstItem()); ?></td>
      <td>
        <img src="<?php echo e(asset('sampulbuku/'.$row->sampul)); ?>" alt="" style="width:120px;">
      </td>
      <td><?php echo e($row->judul); ?></td>
      <td><?php echo e($row->penulis); ?></td>
      <td><?php echo e($row->penerbit); ?></td>
      <td><?php echo e($row->jenis_buku); ?></td>
      <td><?php echo e($row->stok); ?></td>
      <td><label class="label <?php echo e(($row->status ==1) ? 'label-success' : 'label-danger'); ?>"><?php echo e(($row->status ==1) ? 'Aktif' : 'Tidak Aktif'); ?></label></td>
      <td><?php echo e($row->created_at->format('D M Y')); ?></td>
      <td>
        <?php if($row->status == 1): ?>
        <a href="<?php echo e(url ('buku/status/'.$row->id)); ?>"class="btn btn-danger">Non Aktifkan</a>
        <?php else: ?>
        <a href="<?php echo e(url ('buku/status/'.$row->id)); ?>"class="btn btn-success"> Aktifkan</a>
        <?php endif; ?>
      </td>
      <td>
<a href="/tampilkandata/<?php echo e($row->id); ?>" class="btn btn-info"><i class="bi bi-pencil-square"></i></a>
<a href="#" type="button" class="btn btn-danger delete mt-1" data-id="<?php echo e($row->id); ?>" data-judul="<?php echo e($row->judul); ?>"><i class="bi bi-trash3"></i></a>
</td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div style="margin-left:40%">
<?php echo e($data->links()); ?>

          </div>
        </div>
    </div>
    </div>
    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js" integrity="sha512-VEd+nq25CkR676O+pLBnDW09R7VQX9Mdiij052gVCp5yVH3jGtH70Ho/UUv4mJDsEdTvqRCFZg0NKGiojGnUCw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
    -->
  </body>
  <script>
$('.delete').click( function(){
  var bukuid = $(this).attr('data-id');
  var judul = $(this).attr('data-judul');

  swal({
  title: "Apakah Anda Yakin ?",
  text: "Akan Menghapus Data Buku Dengan Judul "+judul+" ",
  icon: "warning",
  buttons: true,
  dangerMode: true,
})
.then((willDelete) => {
  if (willDelete) {
    window.location = "/delete/"+bukuid+""
    swal("Data Berhasil Dihapus", {
      icon: "success",
    });
  } else {
    swal("Data Tidak Jadi Dihapus");
  }
});
});
    </script>
    <script>
      <?php if(Session::has('success')): ?>
      toastr.success("<?php echo e(Session::get('success')); ?>")
      <?php endif; ?>
      </script>
      </div>
</body>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\application\project_sips\resources\views/buku.blade.php ENDPATH**/ ?>