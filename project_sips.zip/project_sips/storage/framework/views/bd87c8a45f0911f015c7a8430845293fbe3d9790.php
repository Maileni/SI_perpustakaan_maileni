
<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>Si Perpustakaan</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">
    <link rel="stylesheet" href="<?php echo e(asset('css/card.css')); ?>">
    <script src="fontawesome/all.js"></script>
</head>
<body>
<div class="head-title">
				<div class="left">
					<h1>Daftar Buku</h1>
					<ul class="breadcrumb">
						<li>
							<a href="/daftarbuku">Daftar Buku</a>
						</li>
						<li><i class='bx bx-chevron-right' ></i></li>
						<li>
							<a class="active" href="/home">Beranda</a>
						</li>
					</ul>
          </div>
</div>
          <?php if(session('message')): ?>
        <div class="alert <?php echo e(session('alert-class')); ?>">
            <?php echo e(session('message')); ?>

</div>
<?php endif; ?>
        <form action="/daftarbuku" method="GET">
        <div class="input-group" style="width:220px;">
  <input type="search" class="form-control" name="search"placeholder="cari kategori.."  ></div><br>
<div class="col-md-12 mb-5 d-flex flex-wrap">
        <?php $__currentLoopData = $buku; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buku): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4">
            <div class="card">
        <div class="head-card">
                <img src="<?php echo e(url('sampulbuku')); ?>/<?php echo e($buku->sampul); ?>" class="card-img-top"alt="..." style="height: 200px;width:200px;">
                <div class="card-body">
                    <h5 class="card-title"><?php echo e($buku->judul); ?></h5>
                     <p class="card-text">
                    <strong>Kategori : </strong><?php echo e($buku->jenis_buku); ?><br>
                    <strong>Stok : </strong><?php echo e($buku->stok); ?>

</p>
                    <a href="<?php echo e(url('detail')); ?>/<?php echo e($buku->id); ?>" class="btn btn-primary"><i class="bi bi-book"></i> Detail</a>
                    <a href="<?php echo e(url('pinjam/'.$buku->id)); ?>" class="btn btn-success"><i class="bi bi-bag"></i> Pinjam</a>
                </div>
        </div>
        </div>
                </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>
</body>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\application\project_sips\resources\views/daftarbuku.blade.php ENDPATH**/ ?>