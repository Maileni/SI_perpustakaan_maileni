

<?php $__env->startSection('content'); ?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.css" integrity="sha512-3pIirOrwegjM6erE5gPSwkUzO+3cTjpnV9lexlNZqvupR64iZBnOOTiiLPb9M36zpMScbmUNIcHUqKD47M719g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title>SI Perpustakaan</title>
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<div class="col-12 col-md-8 offset-md-2 col-lg-6 offset-md-3">
<link rel="stylesheet" href="<?php echo e(asset('css/img.css')); ?>">
    <h1 class="mb-5"style="font-family:Times;color:#5F9EA0">Sips</h1>
    <div class="col-md-12 mt-2">
                        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(url('home')); ?>">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">Peminjaman</li>
            </ol>
            </nav>
            </div>
    <style>
            html, body {
                background-color:white;
                background-size:cover;
                background-repeat: no-repeat;
                color: #759291;
                font-family:cambria;
                font-weight: 200;
                height: 100vh;
                margin: 0;
            }
</style>
    <div class="mt-5">
        <?php if(session('message')): ?>
        <div class="alert <?php echo e(session('alert-class')); ?>">
            <?php echo e(session('message')); ?>

</div>
<?php endif; ?>
</div>
    <form action="book-rent" method="post">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="user" class="form-label">Nama Peminjam</label>
            <select name="user_id" id="user" class="form-control inputbox">
                <option value="">Pilih Nama</option>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
</div>
        <div class="mb-3">
            <label for="book" class="form-label">Judul Buku</label>
            <select name="book_id" id="book" class="form-control inputbox">
            <option value="">Pilih Buku</option>
                <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($item->id); ?>"><?php echo e($item->judul); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
</div>
<div>
<button>
  <span class="transition"></span>
  <span class="gradient"></span>
  <span class="label">submit</span>
</button>
</div>
</form>
</div>

<script src="https://code.jquery.com/jquery-3.6.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script>$(document).ready(function() {
    $('.inputbox').select2();

});</script>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\application\project_sips\resources\views/book-rent.blade.php ENDPATH**/ ?>