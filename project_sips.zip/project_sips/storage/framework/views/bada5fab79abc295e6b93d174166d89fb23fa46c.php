
<?php $__env->startSection('content'); ?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<div class="head-title">
<title>SI Perpustakaan</title>
				<div class="left">
					<h1>Detail Buku</h1>
					<ul class="breadcrumb">
						<li>
							<a href="/detail">Detail peminjaman</a>
						</li>
						<li><i class='bx bx-chevron-right' ></i></li>
						<li>
							<a class="active" href="/home">Beranda</a>
						</li>
					</ul>
          </div>
  </head>
  <body>
            <div class="col-12">
               <div class="card">
                <div class="card-header"style=background-color:#5e8f81;font-family:cambria;color:white>
                    <h4><?php echo e($buku->judul); ?></h4>
                </div>
                <div class="card-body">
                    <div class="row">
                    <div class="col-md-2 mt-2">
                            <img src="<?php echo e(url('sampulbuku')); ?>/<?php echo e($buku->sampul); ?>" class="rounded mx-auto d-block" width="150" alt=""><br>
                        </div>
                        <div class="col-12">
                            <table class="table">
                                <tbody>
                                    <tr>
                                        <td>Nama Penulis</td>
                                        <td>:</td>
                                        <td><?php echo e($buku->penulis); ?></td>
                                             </tr>
                                    <tr>
                                        <td>Nama Penerbit</td>
                                        <td>:</td>
                                        <td><?php echo e($buku->penerbit); ?></td>
                                             </tr>
                                    <tr>
                                        <td>Kategori</td>
                                        <td>:</td>
                                        <td><?php echo e($buku->jenis_buku); ?></td>
                                             </tr>
                                             <tr>
                                        <td>Stok</td>
                                        <td>:</td>
                                        <td><?php echo e($buku->stok); ?></td>
                                             </tr>
                                    <tr>
                                        <td>Status</td>
                                        <td>:</td>
                                        <td><label class="label <?php echo e(($buku->status ==1) ? 'label-success' : 'label-danger'); ?>"><?php echo e(($buku->status ==1) ? 'Aktif' : 'Tidak Aktif'); ?></label></td>
                                             </tr>
        </tbody>
        </table>
                    </div>
                </div>
               </div>
            </div>
        </div>
        </div>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\application\project_sips\resources\views/detail.blade.php ENDPATH**/ ?>