<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <title>SI Perpustakaan</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.css" integrity="sha512-3pIirOrwegjM6erE5gPSwkUzO+3cTjpnV9lexlNZqvupR64iZBnOOTiiLPb9M36zpMScbmUNIcHUqKD47M719g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        @media  only screen and (max-width:800px) {
            #no-more-tables tbody,
            #no-more-tables tr,
            #no-more-tables td {
                display: block;
            }
            #no-more-tables thead tr {
                position: absolute;
                top: -9999px;
                left: -9999px;
            }
            #no-more-tables td {
                position: relative;
                padding-left: 50%;
                border: none;
                border-bottom: 1px solid #5e8f81;
            }
            #no-more-tables td:before {
                content: attr(data-title);
                position: absolute;
                left: 6px;
                font-weight: bold;
            }
            #no-more-tables tr {
                border-bottom: 1px solid #ccc;
            }
        }
    </style>
    <div class="container">
        <div class="row">
<h1 class="text-center mb-2"style="font-family:Times;color:black"target="_blank">Laporan Peminjaman buku</h1>
<body>
<div class="table-responsive" id="no-more-tables">
            <table class="table"style="background-color:#92b8ad; font-family:cambria;color:white;">
                <thead style=background-color:#5e8f81;font-family:cambria;color:white>
                    <tr>
                    <th scope="col">No</th>
      <th scope="col">Peminjam</th>
      <th scope="col">Judul Buku</th>
      <th scope="col">Status</th>
      <th scope="col">Waktu meminjam</th>
      <th scope="col">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $datacetak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e => $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
    <td><?php echo e($e+1); ?></td>
    <td><?php echo e($dt->user_r->name); ?></td>
      <td><?php echo e($dt->book_r->judul); ?></td>
      <?php if($dt->status == 1): ?>
      <td><label class="label label-success">Sedang Dipinjam</label></td>
      <?php else: ?>
      <td><label class="label label-warning">Sudah Dikembalikan</label></td>
      <?php endif; ?>
      <td><?php echo e($dt->created_at); ?></td>
      <?php if($dt->status==1): ?>
      <td>
        <a href="<?php echo e(url('pengembalian/'.$dt->id)); ?>" class="btn btn-primary">Kembalikan</a>
      </td>
      <?php else: ?>
      <td></td>
      <?php endif; ?>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
  </table>

</div>
</div>
</div>
<script type="text/javascript">
    window.print();
    </script>
</body>
</html>
<?php /**PATH D:\application\project_sips\resources\views/cetakpengembalian.blade.php ENDPATH**/ ?>