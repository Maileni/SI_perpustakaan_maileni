
<?php $__env->startSection('content'); ?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <title>SI Perpustakaan</title>
			<div class="head-title">
				<div class="left">
					<h1>Profile User</h1>
					<ul class="breadcrumb">
						<li>
							<a href="/profile">Data Diri</a>
						</li>
						<li><i class='bx bx-chevron-right' ></i></li>
						<li>
							<a class="active" href="/home">Beranda</a>
						</li>
					</ul>
          </div>
</div>
  </head>
  <body>
  <div class="col-12">
  <div class="card-header"style=background-color:#5e8f81;font-family:cambria;color:white>
  <h4><i class="bi bi-person-check"></i> Data Diri</h4>
</div>
            <div class="card-body">
            <div class="row">
            <div class="col-12">
            <table class="table">
              <tbody>
                <tr>
                  <td>Nama</td>
                  <td width="10">:</td>
                  <td><?php echo e($user->name); ?></td>
                </tr>

                <tr>
                  <td>Email</td>
                  <td>:</td>
                  <td><?php echo e($user->email); ?></td>
                </tr>

                <tr>
                  <td>Jenis Kelamin</td>
                  <td>:</td>
                  <td><?php echo e($user->jenis_kelamin); ?></td>
                </tr>

                <tr>
                  <td>Kelas</td>
                  <td>:</td>
                  <td><?php echo e($user->kelas); ?></td>
                </tr>

                <tr>
                  <td>Jurusan</td>
                  <td>:</td>
                  <td><?php echo e($user->jurusan); ?></td>
                </tr>

                <tr>
                  <td>Alamat</td>
                  <td>:</td>
                  <td><?php echo e($user->address); ?></td>
                </tr>

                <tr>
                  <td>Telepon</td>
                  <td>:</td>
                  <td><?php echo e($user->phone); ?></td>
                </tr>
              </tbody>
            </table>

            </div>
          </div>
</div>


</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\application\project_sips\resources\views/profile.blade.php ENDPATH**/ ?>