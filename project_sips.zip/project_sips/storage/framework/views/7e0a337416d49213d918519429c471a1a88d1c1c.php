

<?php $__env->startSection('content'); ?>
<!doctype html>
<html lang="en">

<head>
    <title>SI Perpustakaan</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,shrink-to-fit=no">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.css" integrity="sha512-3pIirOrwegjM6erE5gPSwkUzO+3cTjpnV9lexlNZqvupR64iZBnOOTiiLPb9M36zpMScbmUNIcHUqKD47M719g==" crossorigin="anonymous" referrerpolicy="no-referrer" />

    <style>
        @media  only screen and (max-width:800px) {
            #no-more-tables tbody,
            #no-more-tables tr,
            #no-more-tables td {
                display: block;
            }
            #no-more-tables thead tr {
                position: absolute;
                top: -9999px;
                left: -9999px;
            }
            #no-more-tables td {
                position: relative;
                padding-left: 50%;
                border: none;
                border-bottom: 1px solid #5e8f81;
            }
            #no-more-tables td:before {
                content: attr(data-title);
                position: absolute;
                left: 6px;
                font-weight: bold;
            }
            #no-more-tables tr {
                border-bottom: 1px solid #ccc;
            }
        }
    </style>
</head>
<div class="head-title">
				<div class="left">
					<h1>Laporan Peminjaman</h1>
					<ul class="breadcrumb">
						<li>
							<a href="/catatanpeminjaman">Laporan Peminjaman</a>
						</li>
						<li><i class='bx bx-chevron-right' ></i></li>
						<li>
							<a class="active" href="/home">Beranda</a>
						</li>
					</ul>
          </div>
    </div>
    <?php if(auth()->user()->role=="admin"): ?>
    <a href="/cetakdata" class="btn btn-success mb-2"style="font-family:Times;"><i class="bi bi-filetype-pdf"></i> cetak</a>
    <?php endif; ?>
<body>
        <div class="table-responsive" id="no-more-tables">
            <table class="table"style="background-color:#92b8ad; font-family:cambria;color:white;">
                <thead style=background-color:#5e8f81;font-family:cambria;color:white>
                    <tr>
                    <th scope="col">No</th>
      <th scope="col">Peminjam</th>
      <th scope="col">Judul Buku</th>
      <th scope="col">Waktu Meminjam</th>
      <th scope="col">Status Peminjaman</th>
      <?php if(auth()->user()->role=="admin"): ?>
      <th scope="col">Aksi</th>
      <?php endif; ?>
                    </tr>
                </thead>
                <tbody>
  <?php
      $no = 1;
    ?>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e => $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
    <td><?php echo e($e + $data->firstItem()); ?></td>
      <td><?php echo e($dt->user_r->name); ?></td>
      <td><?php echo e($dt->book_r->judul); ?></td>
      <td><?php echo e($dt->created_at); ?></td>
      <?php if($dt->status == null): ?>
      <td><label class="label label-warning">Menunggu Verifikasi</label></td>
      <?php elseif($dt->status == 1): ?>
      <td><label class="label label-success">Disetujui</label></td>
      <?php elseif($dt->status == 2): ?>
      <td><label class="label label-danger">Ditolak</label></td>
      <?php endif; ?>
      <?php if(auth()->user()->role=="admin"): ?>
      <?php if($dt->status == null): ?>
      <td><a href="<?php echo e(url('pinjam/setujui/'.$dt->id)); ?>" class="btn btn-primary"><i class="bi bi-check-all"></i> Setujui</a>
      <a href="<?php echo e(url('pinjam/tolak/'.$dt->id)); ?>" class="btn btn-danger"><i class="bi bi-x"></i> Tolak</a></td>
    <?php elseif($dt->status == 1): ?>
    <td><a href="<?php echo e(url('pinjam/tolak/'.$dt->id)); ?>" class="btn btn-danger"><i class="bi bi-x"></i> Tolak</a></td>
    <?php elseif($dt->status == 2): ?>
    <td><a href="<?php echo e(url('pinjam/setujui/'.$dt->id)); ?>" class="btn btn-primary"><i class="bi bi-check-all"></i> Setujui</a></td>
    <?php endif; ?>
    </tr>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div style="margin-left:25%">
<?php echo e($data->links()); ?>

</div>
</body>

</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\application\project_sips\resources\views/pinjam.blade.php ENDPATH**/ ?>