<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
</head>
    <title>SI Perpustakaan</title>
<main>
			<div class="head-title">
				<div class="left">
					<h1>Home</h1>
					<ul class="breadcrumb">
						<li>
							<a href="#">Beranda</a>
						</li>
						<li><i class='bx bx-chevron-right' ></i></li>
						<li>
							<a class="active" href="/home">Beranda</a>
						</li>
					</ul>
				</div>
			</div>
			<div class="card">
  <div class="card-header"style=background-color:#5e8f81;font-family:cambria;color:white>
    Welcome to Sips
  </div>
  <div class="card-body"style="background-color:#92b8ad; font-family:cambria;color:white;">
  <div class="col-md-2">
  <img src="<?php echo e(url('sampulbuku/mai3.png')); ?>" class="rounded mx-auto d-block" width="200"alt="">
    <br><h5 class="card-title">Hii! <?php echo e(Auth::user()->name); ?></h5>
	<h6>Pinjam buku oke !!</h6>
  </div>
</div>
</div>
</div>

<div class="card mt-3 md-2" style="max-width: 540px;background-color:#88847f; ">
  <div class="row g-0">
    <div class="col-md-4">
      <img src="<?php echo e(url('sampulbuku/komik.jpeg')); ?>" class="img-fluid rounded-start" width=""alt="...">
    </div>
    <div class="col-md-8">
      <div class="card-body">
        <b><h5 style="color:white;font-family:cambria;" class="card-title">Kategori Buku :</h5></b>
        <p style="color:white;font-family:cambria;" class="card-text">1.Buku Komik<br>
      2.Buku Ensiklopedia
    <br>
  3.Buku Dongeng
<br>
4.Buku Biografi
<br>
5.Buku Novel
<br>
6.Buku Pelajaran</p>
		<i style="color:white;"class="bi bi-star-fill"></i> <i style="color:white;"class="bi bi-star-half"></i> <i style="color:white;" class="bi bi-star"></i>
      </div>
    </div>
  </div>
</div>
		<!-- MAIN -->
		</html>
        <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\application\project_sips\resources\views/home.blade.php ENDPATH**/ ?>