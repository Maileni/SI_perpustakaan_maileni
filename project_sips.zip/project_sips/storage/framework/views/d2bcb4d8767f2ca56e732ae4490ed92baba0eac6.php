<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<!-- Boxicons -->
	<link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
	<!-- My CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/sidebar.css')); ?>">

	<title>SI Perpustakaan</title>
</head>
<body>
	<!-- SIDEBAR -->
	<section id="sidebar">

		<a href="#" class="brand">
		<i class='bx bx-book-reader'></i>
			<span class="text">Sips</span>
		</a>
		<ul class="side-menu top">
			<li class="active">
				<a href="/home">
					<i class='bx bx-home-circle' ></i>
					<span class="text">Beranda</span>
				</a>
			</li>
			<?php if(auth()->user()->role=="admin"): ?>
			<li>
				<a href="/buku">
				<i class='bx bx-book-bookmark' ></i></i>
					<span class="text">Daftar Buku</span>
				</a>
			</li>
			<?php endif; ?>

			<?php if(auth()->user()->role=="user"): ?>
			<li>
				<a href="/daftarbuku">
				<i class='bx bx-book-bookmark' ></i></i>
					<span class="text">Daftar Buku</span>
				</a>
			</li>
			<?php endif; ?>

			<?php if(auth()->user()->role=="admin"): ?>
			<li>
				<a href="/pengguna">
				<i class='bx bxs-user-pin'></i>
					<span class="text">Daftar Anggota</span>
				</a>
			</li>
			<?php endif; ?>

			<?php if(auth()->user()->role=="user"): ?>
			<li>
				<a href="/anggota">
				<i class='bx bxs-user-pin'></i>
					<span class="text">Daftar Anggota</span>
				</a>
			</li>
			<?php endif; ?>


			<li>
				<a href="/pinjam">
				<i class='bx bx-task' ></i></i>
					<span class="text">Riwayat Transaksi</span>
				</a>
			</li>


			<?php if(auth()->user()->role=="admin"): ?>
			<li>
				<a href="/pengembalian">
				<i class='bx bxs-data' ></i></i>
					<span class="text">Pengembalian Buku</span>
				</a>
			</li>
			<?php endif; ?>

		</ul>
		<ul class="side-menu">
		<li>
				<a href="/profile">
					<i class='bx bxs-group' ></i>
					<span class="text">Data Diri Pengguna</span>
				</a>
			</li>
			<li>
			<a href="<?php echo e(route('logout')); ?>"  class="logout"onclick="event.preventDefault();
         document.getElementById('logout-form').submit();">
            <i class='bx bxs-log-out-circle' ></i>
            <span class="text">Logout</span>
                </a>
                    </li>
                        </a>
                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                             <?php echo csrf_field(); ?>
                               </form>
			</li>
		</ul>
	</section>
	<!-- SIDEBAR -->



	<!-- CONTENT -->
	<section id="content">
		<!-- NAVBAR -->
		<nav>
		<i class='bx bxs-dashboard' ></i>
			<a href="#" class="nav-link">Sistem Informasi Perpustakaan Sekolah</a>

		</nav>
		<!-- NAVBAR -->

		<!-- MAIN -->
        <main class="py-4">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
	</section>
	<!-- CONTENT -->


	<script src="script.js"></script>
</body>
</html>
<?php /**PATH D:\application\project_sips\resources\views/layouts/app.blade.php ENDPATH**/ ?>