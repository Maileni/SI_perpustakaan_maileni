
<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>Responsive Card</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">
    <link rel="stylesheet" href="<?php echo e(asset('css/card.css')); ?>">
    <script src="fontawesome/all.js"></script>
</head>
<body>
<div class="head-title">
				<div class="left">
					<h1>Daftar Anggota</h1>
					<ul class="breadcrumb">
						<li>
							<a href="/daftarbuku">Daftar Anggota</a>
						</li>
						<li><i class='bx bx-chevron-right' ></i></li>
						<li>
							<a class="active" href="/home">Beranda</a>
						</li>
					</ul>
          </div>
</div>
        <form action="/anggota" method="GET">
        <div class="input-group"style="width:242px;">
  <input type="search" class="form-control" name="search"placeholder="cari anggota..."  >
</div><br>
<div class="col-md-12 mb-5 d-flex flex-wrap">
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4">
            <div class="card">
        <div class="head-card">

                <div class="card-body">
                    <h5 class="card-title"><?php echo e($user->name); ?></h5>
                     <p class="card-text">
                     <strong>Email : </strong><?php echo e($user->email); ?>

                        <br>
                        <strong>Jenis Kelamin : </strong><?php echo e($user->jenis_kelamin); ?>

                        <br>
                        <strong>Kelas : </strong><?php echo e($user->kelas); ?>

                        <br>
                        <strong>Jurusan : </strong><?php echo e($user->jurusan); ?>

                        <hr>
                        <strong>Telepon : </strong>
                        <?php echo e($user->phone); ?>

                        <br>
                        <strong>Alamat : </strong><?php echo e($user->address); ?>

</p>
                </div>
        </div>
        </div>
                </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div style="margin-left:40%">
<?php echo e($users->links()); ?>

          </div>
</body>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\application\project_sips\resources\views/anggota.blade.php ENDPATH**/ ?>