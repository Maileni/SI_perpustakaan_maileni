

<?php $__env->startSection('content'); ?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.css" integrity="sha512-3pIirOrwegjM6erE5gPSwkUzO+3cTjpnV9lexlNZqvupR64iZBnOOTiiLPb9M36zpMScbmUNIcHUqKD47M719g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<link rel="stylesheet" href="<?php echo e(asset('css/img.css')); ?>">
<title>SI Perpustakaan</title>
			<div class="head-title">
				<div class="left">
					<h1>Form Peminjaman</h1>
					<ul class="breadcrumb">
						<li>
							<a href="/peminjaman">Form Peminjaman</a>
						</li>
						<li><i class='bx bx-chevron-right' ></i></li>
						<li>
							<a class="active" href="/home">Home</a>
						</li>
					</ul>
          </div>
          <div class="col-md-12 mt-2">
        <?php if(session('message')): ?>
        <div class="alert <?php echo e(session('alert-class')); ?>">
            <?php echo e(session('message')); ?>

</div>
<?php endif; ?>
</div>
<div class="col-md-12 mt-2">
    <form action="peminjaman" method="post">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="name" class="form-label">Nama Peminjam</label>
            <select name="id_user" id="name" class="form-control inputbox">
                <option value="">Pilih Nama</option>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
</div>
        <div class="mb-3">
            <label for="buku" class="form-label">Judul Buku</label>
            <select name="id_buku" id="buku" class="form-control inputbox">
            <option value="">Pilih Buku</option>
                <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($item->id); ?>"><?php echo e($item->judul); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
</div>
        <!-- <div class="mb-3">
            <label for="buku" class="form-label">Tanggal meminjam</label>
            <input type="date" name="date" id="date" class="form-control"></input>
</div>
        <div class="mb-3">
            <label for="buku" class="form-label">Tanggal mengembalikan</label>
            <input type="date" name="date" id="date" class="form-control"></input>
</div> -->
<div>
<button>
  <span class="transition"></span>
  <span class="gradient"></span>
  <span class="label"><i class="bi bi-download"></i> submit</span>
</button>
</div>
</form>
</div>

<script src="https://code.jquery.com/jquery-3.6.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script>$(document).ready(function() {
    $('.inputbox').select2();

});</script>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\application\project_sips\resources\views/peminjaman.blade.php ENDPATH**/ ?>