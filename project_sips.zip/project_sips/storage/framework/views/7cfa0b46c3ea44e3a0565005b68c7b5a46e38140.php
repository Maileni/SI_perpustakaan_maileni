

<?php $__env->startSection('title'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
  <!-- Success Message -->
   <link rel="stylesheet" href="<?php echo e(asset('css/img.css')); ?>">
  <style>
            html, body {
                background-image:url('<?php echo e(asset('sampulbuku/mai3.png')); ?>');
                background-size:cover;
                background-repeat: no-repeat;
                color: #759291;
                font-family: cambria;
                font-weight: 200;
                height: 100vh;
                margin: 0;
            }
</style>
<div class="row justify-content-center">
  <div class="col-md-2">
  <div class="card" style="width:350px;">
  <div class="card-body">
    <h5 class="card-title"style="font-family:Times;color:#5F9EA0">Tambah Profile</h5>
    <div class="card-body">
                    <form action="/insertprofile" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">image</label>
    <input type="file" name="image" class="form-control <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"value="<?php echo e(old('image')); ?>">
    <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="invalid-feedback"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>
  
</div>
<button>
  <span class="text">Button</span>
</button>
        </div>
      </div>
      </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\application\project_sips\resources\views/tambahprofile.blade.php ENDPATH**/ ?>