<!-- <!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SI Perpustakaan</title>
    <link rel="stylesheet" href="{{ asset('css/login.css') }}">
</head>

<body>
    <div class="container">
        <div class="login">
        <form method="POST" action="{{ route('register') }}">
                        @csrf
                <h1>Register</h1>
                <hr>
                <p>Create you account!!</p>
                <input id="name" type="text" class="form-control @error('name') is-invalid @enderror" name="name" value="{{ old('name') }}" autocomplete="name" autofocus placeholder="Nama">

                                @error('name')
                                    <span class="invalid-feedback" role="alert" style="font-size:10px;color:red;">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                <input id="email" type="email" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}" autocomplete="email"placeholder="Email">

@error('email')
    <span class="invalid-feedback" role="alert" style="font-size:10px;color:red;">
        <strong>{{ $message }}</strong>
    </span>
@enderror
                <input id="password" type="password" class="form-control @error('password') is-invalid @enderror" name="password" autocomplete="new-password"placeholder="Kata Sandi">

@error('password')
    <span class="invalid-feedback" role="alert" style="font-size:10px;color:red;">
        <strong>{{ $message }}</strong>
    </span>
@enderror

                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" autocomplete="new-password"placeholder=" Confirm Password">

                <input id="jenis_kelamin" type="jenis_kelamin" class="form-control @error('jenis_kelamin') is-invalid @enderror" name="jenis_kelamin" value="{{ old('jenis_kelamin') }}" autocomplete="jenis_kelamin"placeholder="Jenis Kelamin">

@error('jenis_kelamin')
    <span class="invalid-feedback" role="alert" style="font-size:10px;color:red;">
        <strong>{{ $message }}</strong>
    </span>
@enderror

<input id="kelas" type="kelas" class="form-control @error('kelas') is-invalid @enderror" name="kelas" value="{{ old('kelas') }}" autocomplete="kelas"placeholder="Kelas">

@error('kelas')
    <span class="invalid-feedback" role="alert" style="font-size:10px;color:red;">
        <strong>{{ $message }}</strong>
    </span>
@enderror


<input id="jurusan" type="jurusan" class="form-control @error('jurusan') is-invalid @enderror" name="jurusan" value="{{ old('jurusan') }}" autocomplete="jurusan"placeholder="Jurusan">

@error('jurusan')
    <span class="invalid-feedback" role="alert" style="font-size:10px;color:red;">
        <strong>{{ $message }}</strong>
    </span>
@enderror




                <input id="address" type="address" class="form-control @error('address') is-invalid @enderror" name="address" value="{{ old('address') }}" autocomplete="address"placeholder="Alamat">

@error('address')
    <span class="invalid-feedback" role="alert" style="font-size:10px;color:red;">
        <strong>{{ $message }}</strong>
    </span>
@enderror
<input id="phone" type="phone" class="form-control @error('phone') is-invalid @enderror" name="phone" value="{{ old('phone') }}" autocomplete="phone"placeholder="No.Telepon">

@error('phone')
    <span class="invalid-feedback" role="alert" style="font-size:10px;color:red;">
        <strong>{{ $message }}</strong>
    </span>
@enderror
<button type="submit" class="btn btn-success col-10">
                                    {{ __('Register') }}
                                </button>
            </form>
        </div>
        <div class="right">
        <img src="sampulbuku/mai4.png" alt="">
        </div>
    </div>
</body>

</html> -->
