<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SI Perpustakaan</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">
    <link rel="stylesheet" href="{{ asset('css/login.css') }}">
</head>
<body>
    <div class="container">
        <div class="login">
        <form method="POST" action="{{ route('login') }}">
                        @csrf

						<center><img src="sampulbuku/logoaku.png" width="200px"></center>
                <hr>
                <p>Selamat Datang !!!</p>
                <br>
                <br>

                <label style="color:#5e8f81;font-family:cambria;font-size:80%"><i class="bi bi-envelope-at"></i> Gmail</label>
                <input id="email" type="email" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}" autocomplete="email" placeholder="Silahkan Masukan Email Kamu">

                                @error('email')
                                    <span class="invalid-feedback" style="color:red;font-family:cambria;font-size:70%"role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror

                               <label style="color:#5e8f81;font-family:cambria;font-size:80%"><i class="bi bi-lock"></i> Kata Sandi</label>
                <input id="password" type="password" class="form-control @error('password') is-invalid @enderror" name="password" autocomplete="new-password"   placeholder="Silahkan Maukan Nisn Kamu">

@error('password')
    <span class="invalid-feedback"style="color:red;font-family:cambria;font-size:70%" role="alert">
        <strong >{{ $message }}</strong>
    </span>
@enderror


<button type="submit" class="btn btn-success col-12">
                                    {{ __('login') }}
                                </button>
            </form>
        </div>
        <div class="right">
        <img src="sampulbuku/mai4.png" alt="">
        </div>
    </div>
</body>

</html>
