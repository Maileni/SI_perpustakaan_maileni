<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SI Perpustakaan</title>
    <link rel="stylesheet" href="{{ asset('css/login.css') }}">
</head>

<body>
@if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif
    <div class="container">
        <div class="login">
        <form method="POST" action="{{ route('password.email') }}">
                        @csrf
                <h1>RESET PASSWORD</h1>
                <hr>
                <p>Sistem Informasi Perpustakaan Sekolah!!</p>
                <label for="">Email</label>
                <input id="email" type="email" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}" required autocomplete="email" autofocus>

@error('email')
    <span class="invalid-feedback" role="alert">
        <strong>{{ $message }}</strong>
    </span>
@enderror
<button type="submit" class="btn btn-primary">
                                    {{ __('Send Password Reset Link') }}
                                </button>
            </form>
        </div>
        <div class="right">
        <img src="sampulbuku/mai4.png" alt="">
        </div>
    </div>
</body>

</html>
