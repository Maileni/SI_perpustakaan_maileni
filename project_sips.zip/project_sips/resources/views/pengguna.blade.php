@extends('layouts/app')

@section('content')
<!doctype html>
<html lang="en">

<head>
    <title>SI Perpustakaan</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,shrink-to-fit=no">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.css" integrity="sha512-3pIirOrwegjM6erE5gPSwkUzO+3cTjpnV9lexlNZqvupR64iZBnOOTiiLPb9M36zpMScbmUNIcHUqKD47M719g==" crossorigin="anonymous" referrerpolicy="no-referrer" />

    <style>
        @media only screen and (max-width:800px) {
            #no-more-tables tbody,
            #no-more-tables tr,
            #no-more-tables td {
                display: block;
            }
            #no-more-tables thead tr {
                position: absolute;
                top: -9999px;
                left: -9999px;
            }
            #no-more-tables td {
                position: relative;
                padding-left: 50%;
                border: none;
                border-bottom: 1px solid #5e8f81;
            }
            #no-more-tables td:before {
                content: attr(data-title);
                position: absolute;
                left: 6px;
                font-weight: bold;
            }
            #no-more-tables tr {
                border-bottom: 1px solid #ccc;
            }
        }
    </style>
</head>
<div class="head-title">
				<div class="left">
					<h1>Kelola Pengguna</h1>
					<ul class="breadcrumb">
						<li>
							<a href="/catatanpeminjaman">Kelola Pengguna</a>
						</li>
						<li><i class='bx bx-chevron-right' ></i></li>
						<li>
							<a class="active" href="/home">Beranda</a>
						</li>
					</ul>
          </div>
    </div>
    @if (session('message'))
        <div class="alert {{session('alert-class')}}">
            {{ session('message') }}
</div>
@endif
    <a href="/tambahpengguna" class="btn btn-success mb-4"style="font-family:Times;"><i class="bi bi-cloud-plus"></i> Tambah</a>
    <form action="/pengguna" method="GET">
        <div class="input-group" style="width:200px;">
  <input type="search" class="form-control" name="search"placeholder="cari..">
</div>
        </form>
        </div>
<body>
        <div class="table-responsive mt-2" id="no-more-tables">
            <table class="table"style="background-color:#92b8ad; font-family:cambria;color:white;">
                <thead style=background-color:#5e8f81;font-family:cambria;color:white>
                    <tr>
                    <th scope="col">No</th>
      <th scope="col">Nama</th>
      <th scope="col">Email</th>
      <th scope="col">Jenis Kelamin</th>
      <th scope="col">Kelas</th>
      <th scope="col">Jurusan</th>
      <th scope="col">Alamat</th>
      <th scope="col">No.Telepon</th>
      <th scope="col">Kedudukan</th>
      <th scope="col">Aksi</th>
                    </tr>
                </thead>
                <tbody>
  @php
      $no = 1;
    @endphp
    @foreach ($pengguna as $p => $pg )
    <tr>
    <td>{{ $p + $pengguna->firstItem() }}</td>
      <td>{{ $pg->name}}</td>
      <td>{{ $pg->email}}</td>
      <td>{{ $pg->jenis_kelamin}}</td>
      <td>{{ $pg->kelas}}</td>
      <td>{{ $pg->jurusan}}</td>
      <td>{{ $pg->address}}</td>
      <td>{{ $pg->phone}}</td>
      <td>{{ $pg->role}}</td>
        <td>

            <a href="/edit/{{ $pg->id }}" class="btn btn-info"><i class="bi bi-pencil-square"></i></a>
            <form action="/pengguna/{{ $pg->id }}" method="post" class="d-inline">
                @csrf
                @method('delete')
                <button type="submit" class="btn btn-danger mt-1" data-id="{{ $pg->id}}" onclick="return confirm('Apakah Anda Yakin Ingin Menghapus?')"><i class="bi bi-trash3"></i></button>
            </form>
        </td>
@endforeach
                </tbody>
            </table>
        </div>
        <div style="margin-left:25%">
{{ $pengguna->links() }}
</div>
</body>

</html>
@endsection
