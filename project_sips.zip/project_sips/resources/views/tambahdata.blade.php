@extends('layouts/app')
@section('content')
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <title>SI Perpustakaan</title>
			<div class="head-title">
				<div class="left">
					<h1>Tambah Data Buku</h1>
					<ul class="breadcrumb">
						<li>
							<a href="/tambahdata">Tambah Data Buku</a>
						</li>
						<li><i class='bx bx-chevron-right' ></i></li>
						<li>
							<a class="active" href="/home">Beranda</a>
						</li>
					</ul>
          </div>
     <link rel="stylesheet" href="{{ asset('css/img.css') }}">
  </head>
  <body>

  <div class="col-md-12 mt-2">
     <div class="card">
        <div class="card-body"style="background-color:#92b8ad;color:white;">
        <form action="/insertdata" method="POST" enctype="multipart/form-data">
            @csrf
  <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Judul Buku</label>
    <input type="text" name="judul" class="form-control @error('judul') is-invalid @enderror" id="exampleInputEmail1" aria-describedby="emailHelp" value="{{ old('judul') }}" autofocus>
    @error('judul')
    <div class="invalid-feedback">{{ $message }}</div>
    @enderror
  </div>
  <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Nama Penulis</label>
    <input type="text" name="penulis" class="form-control @error('penulis') is-invalid @enderror" id="exampleInputEmail1" aria-describedby="emailHelp" value="{{ old('penulis') }}">
    @error('penulis')
    <div class="invalid-feedback">{{ $message }}</div>
    @enderror
  </div>
  <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Nama Penerbit</label>
    <input type="text" name="penerbit" class="form-control @error('penerbit') is-invalid @enderror" id="exampleInputEmail1" aria-describedby="emailHelp" value="{{ old('penerbit') }}">
    @error('penerbit')
    <div class="invalid-feedback">{{ $message }}</div>
    @enderror
  </div>
  <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Kategori</label>
    <select name="jenis_buku" class="form-select @error('jenis_buku') is-invalid @enderror" id="exampleInputEmail1" aria-describedby="emailHelp" value="{{ old('jenis_buku') }}">
    <option selected>-pilih-</option>
  <option value="Buku komik">Buku komik</option>
  <option value="Buku Ensiklopedia">Buku Ensiklopedia</option>
  <option value="Buku Dongeng">Buku Dongeng</option>
  <option value="Buku Biografi">Buku Biografi</option>
  <option value="Buku Novel">Buku Novel</option>
  <option value="Buku Pelajaran">Buku Pelajaran</option>
</select>
    @error('jenis_buku')
    <div class="invalid-feedback">{{ $message }}</div>
    @enderror
  </div>
  <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Stok</label>
    <input type="text" name="stok" class="form-control @error('stok') is-invalid @enderror" id="exampleInputEmail1" aria-describedby="emailHelp" value="{{ old('stok') }}">
    @error('stok')
    <div class="invalid-feedback">{{ $message }}</div>
    @enderror
  </div>

  <!-- <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Status</label>
    <select class="form-select @error('status') is-invalid @enderror" name="status" value="{{ old('status') }}">
  <option selected>-pilih-</option>
  <option value="tersedia">1</option>
  <option value="tidak tersedia">0</option>
</select>
@error('status')
    <div class="invalid-feedback">{{ $message }}</div>
    @enderror
  </div> -->
  <div class="mb-3">
    <label for="sampul" class="form-label">Sampul</label>
    <img class="img-preview img-fluid mb-3"style="width: 100px;">
    <input class="form-control @error('sampul') is-invalid @enderror" type="file" id="sampul" name="sampul" onchange="previewImage()" value="{{ old('sampul') }}">
    @error('sampul')
    <div class="invalid-feedback">{{ $message }}</div>
    @enderror
  </div>


  <button>
  <span class="transition"></span>
  <span class="gradient"></span>
  <span class="label"><i class="bi bi-download"></i> Submit</span>
</button>
<a href="/buku" type="button" class="btn btn-success"><i class="bi bi-arrow-left-circle"></i> Kembali</a>
</form>
</div>
    </div>
          </div>
  </body>
</html>
<script>
        function previewImage() {
            const image = document.querySelector('#sampul');
            const imgPreview = document.querySelector('.img-preview');

            imgPreview.style.display = 'block';

            const oFReader = new FileReader();
            oFReader.readAsDataURL(image.files[0]);

            oFReader.onload = function(oFREvent) {
                imgPreview.src = oFREvent.target.result;
            }
        }
    </script>
@endsection
