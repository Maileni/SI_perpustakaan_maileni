@extends('layouts/app')
@section('content')
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <title>SI Perpustakaan</title>
			<div class="head-title">
				<div class="left">
					<h1>Tambah Data Pengguna</h1>
					<ul class="breadcrumb">
						<li>
							<a href="/tambahpengguna">Tambah Data Pengguna</a>
						</li>
						<li><i class='bx bx-chevron-right' ></i></li>
						<li>
							<a class="active" href="/home">Beranda</a>
						</li>
					</ul>
          </div>
     <link rel="stylesheet" href="{{ asset('css/img.css') }}">
  </head>
  <body>

  <div class="col-md-12 mt-2">
     <div class="card">
        <div class="card-body"style="background-color:#92b8ad;color:white;">
        <form action="{{ route('store') }}" method="POST" enctype="multipart/form-data">
            @csrf
  <div class="form-group mt-3">
    <label for="name">Nama</label>
    <input type="text" class="form-control @error('name') is-invalid @enderror" id="name" name="name" value="{{ old('name') }}" autofocus>
    @error('name')
   <div class="invalid-feedback">{{ $message }}</div>
   @enderror
  </div>
  <div class="form-group mt-3">
    <label for="email">Email</label>
    <input type="email" class="form-control @error('email') is-invalid @enderror" id="email" name="email" value="{{ old('email') }}">
    @error('email')
   <div class="invalid-feedback">{{ $message }}</div>
   @enderror
  </div>
  <div class="form-group mt-3">
    <label for="password">Kata Sandi</label>
    <input type="password" class="form-control @error('password') is-invalid @enderror" id="password" name="password" value="{{ old('password') }}" >
    @error('password')
   <div class="invalid-feedback">{{ $message }}</div>
   @enderror
  </div>
  <div class="form-group mt-3">
    <label for="password-confirm">Konfirmasi Kata Sandi</label>
    <input type="password" class="form-control @error('password_confirm') is-invalid @enderror" id="password-confirm" name="password_confirmation">
    @error('password-confirm')
   <div class="invalid-feedback">{{ $message }}</div>
   @enderror
  </div>
  <div class="form-group mt-3">
    <label for="jenis_kelamin">Jenis Kelamin</label>
    <select type="text" class="form-select @error('jenis_kelamin') is-invalid @enderror" id="jenis_kelamin" name="jenis_kelamin" value="{{ old('jenis_kelamin') }}" >
    <option selected>-pilih-</option>
  <option value="Perempuan">perempuan</option>
  <option value="Laki-Laki">Laki-Laki</option>
  </select>
    @error('jenis_kelamin')
   <div class="invalid-feedback">{{ $message }}</div>
   @enderror
  </div>
  <div class="form-group mt-3">
    <label for="kelas">Kelas</label>
    <select type="text" class="form-select @error('kelas') is-invalid @enderror" id="kelas" name="kelas" value="{{ old('kelas') }}" >
    <option selected>-pilih-</option>
  <option value="X">X</option>
  <option value="X1">X1</option>
  <option value="X11">X11</option>
  </select>
    @error('kelas')
   <div class="invalid-feedback">{{ $message }}</div>
   @enderror
  </div>
  <div class="form-group mt-3">
    <label for="jurusan">Jurusan</label>
    <select type="text" class="form-select @error('jurusan') is-invalid @enderror" id="jurusan" name="jurusan" value="{{ old('jurusan') }}">
    <option selected>-pilih-</option>
  <option value="ANIMASI">ANIMASI</option>
  <option value="PPLG">PPLG</option>
  <option value="BROADCASTING">BROADCASTING</option>
  <option value="TKR">TKR</option>
  <option value="TPL">TPL</option>
  </select>
    @error('jurusan')
   <div class="invalid-feedback">{{ $message }}</div>
   @enderror
  </div>
  <div class="form-group mt-3">
    <label for="address">Alamat</label>
    <input type="text" class="form-control @error('address') is-invalid @enderror" id="address" name="address" value="{{ old('address') }}">
    @error('address')
   <div class="invalid-feedback">{{ $message }}</div>
   @enderror
  </div>
  <div class="form-group mt-3">
    <label for="phone">No.Telepon</label>
    <input type="text" class="form-control @error('phone') is-invalid @enderror" id="phone" name="phone" value="{{ old('phone') }}">
    @error('phone')
   <div class="invalid-feedback">{{ $message }}</div>
   @enderror
  </div>

  <br>
  <label for="role">Pilih pengguna sebagai :</label>
  <br>
  <div class="form-check form-check-inline my-3">
  <input name="role" class="form-check-input" type="checkbox" id="role" value="siswa">
  <label class="form-check-label" for="role">Siswa</label>
</div>
  <div class="form-check form-check-inline my-3">
  <input name="role" class="form-check-input" type="checkbox" id="role" value="admin">
  <label class="form-check-label" for="role">Admin</label>
</div>
<br>
<button>
  <span class="transition"></span>
  <span class="gradient"></span>
  <span class="label"><i class="bi bi-download"></i> Submit</span>
</button>
<a href="/buku" type="button" class="btn btn-success"><i class="bi bi-arrow-left-circle"></i> Kembali</a>
</form>
</div>
    </div>
          </div>
  </body>
</html>
@endsection
