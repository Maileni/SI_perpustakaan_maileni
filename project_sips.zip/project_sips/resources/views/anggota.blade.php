@extends('layouts/app')
@section('content')
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>Responsive Card</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">
    <link rel="stylesheet" href="{{ asset('css/card.css') }}">
    <script src="fontawesome/all.js"></script>
</head>
<body>
<div class="head-title">
				<div class="left">
					<h1>Daftar Anggota</h1>
					<ul class="breadcrumb">
						<li>
							<a href="/daftarbuku">Daftar Anggota</a>
						</li>
						<li><i class='bx bx-chevron-right' ></i></li>
						<li>
							<a class="active" href="/home">Beranda</a>
						</li>
					</ul>
          </div>
</div>
        <form action="/anggota" method="GET">
        <div class="input-group"style="width:242px;">
  <input type="search" class="form-control" name="search"placeholder="cari anggota..."  >
</div><br>
<div class="col-md-12 mb-5 d-flex flex-wrap">
        @foreach($users as $user)
        <div class="col-md-4">
            <div class="card">
        <div class="head-card">

                <div class="card-body">
                    <h5 class="card-title">{{ $user->name }}</h5>
                     <p class="card-text">
                     <strong>Email : </strong>{{ $user->email }}
                        <br>
                        <strong>Jenis Kelamin : </strong>{{ $user->jenis_kelamin }}
                        <br>
                        <strong>Kelas : </strong>{{ $user->kelas }}
                        <br>
                        <strong>Jurusan : </strong>{{ $user->jurusan }}
                        <hr>
                        <strong>Telepon : </strong>
                        {{ $user->phone }}
                        <br>
                        <strong>Alamat : </strong>{{ $user->address }}
</p>
                </div>
        </div>
        </div>
                </div>
        @endforeach
    </div>
    <div style="margin-left:40%">
{{ $users->links() }}
          </div>
</body>
</html>
@endsection
