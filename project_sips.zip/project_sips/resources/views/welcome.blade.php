@extends('layouts/sidebar')

@section('content')
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SI Perpustakaan</title>
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="{{ asset('css/landing.css') }}">
</head>

<body>
    <section class="hero-container">
        <div>
            <div>
                <h1>Fill Your Day By Reading
                </h1>
                <p>_.Result of Maileni._
                </p>
            </div>
        </div>
        <img src="sampulbuku/mai3.png" alt="hero">
    </section>

</body>

</html>
@endsection
